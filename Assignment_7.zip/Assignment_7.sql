
/*Consider yourself to be Sam and you have been given the below tasks to
complete using the Table � STUDIES, SOFTWARE and PROGRAMMER*/

--Find out the selling cost average for packages developed in Pascal.

SELECT AVG(SellingCost)
FROM SOFTWARE
WHERE Language = 'Pascal';


--2. Display the names and ages of all programmers.

SELECT Name, Age
FROM PROGRAMMER;

--3.Display the names of those who have done the DAP Course.
SELECT Names
FROM STUDIES
WHERE Course = 'DAP';

--4. Display the names and date of birth of all programmers born in January.

SELECT Names,dateofbirth
FROM PROGRAMMER
WHERE Month = 'January';

--OR

SELECT Name, DateOfBirth
FROM PROGRAMMER
WHERE MONTH(DateOfBirth) = 1;


--5. What is the highest number of copies sold by a package?

SELECT MAX(Copies)
FROM SOFTWARE;

--6. Display lowest course fee.

SELECT MIN(Fee)
FROM STUDIES;

--7. How many programmers have done the PGDCA Course?

SELECT COUNT(*) AS NumberOfProgrammers
FROM STUDIES
WHERE Course = 'PGDCA';


--8. How much revenue has been earned through sales of packages
--developed in C?
SELECT SUM(SellingCost * CopiesSold) AS TotalRevenue
FROM SOFTWARE
WHERE Language = 'C';
--Display the details of the software developed by Ramesh.

select * from software 
where developer = 'Ramesh';

--10. How many programmers studied at Sabhari?

SELECT COUNT(*) AS NumberOfProgrammers
FROM STUDIES
WHERE College = 'Sabhari';

--11. Display details of packages whose sales crossed the 2000 mark.

select * from software 
where CopiesSold>2000;



--12. Display the details of packages for which development costs have been
--recovered.
SELECT *
FROM SOFTWARE
WHERE Revenue >= DevelopmentCost;
--13.What is the cost of the costliest software development in Basic?

SELECT MAX(DevelopmentCost) AS CostliestDevelopmentCost
FROM SOFTWARE
WHERE Language = 'Basic';

--14. How many packages have been developed in dBase?

SELECT COUNT(*) AS NumberOfPackages
FROM SOFTWARE
WHERE Language = 'dBase';


--15. How many programmers studied in Pragathi?

SELECT COUNT(*) AS NumberOfprogrammers
FROM STUDIES
WHERE College = 'Pragathi';

--16. How many programmers paid 5000 to 10000 for their course?

SELECT COUNT(*) AS NumberOfProgrammers
FROM STUDIES
WHERE Fee >= 5000 AND Fee <= 10000;



--17. What is the average course fee?

SELECT AVG(fee) AS Average_course_fee
FROM STUDIES;


--18. Display the details of the programmers knowing C.

SELECT *
FROM PROGRAMMER
WHERE Languages ='C';
 or 
 SELECT *
FROM PROGRAMMER
WHERE 'C' IN (Languages);


--19. How many programmers know either COBOL or Pascal?

SELECT COUNT(*) AS NumberOfProgrammers
FROM PROGRAMMER
WHERE Languages IN ('COBOL', 'Pascal');

--20. How many programmers don�t know Pascal and C?

SELECT COUNT(*) AS NumberOfProgrammers
FROM PROGRAMMER
WHERE Languages NOT IN ('Pascal', 'C');

--21. How old is the oldest male programmer?

SELECT MAX(DATEDIFF(CURRENT_DATE, DateOfBirth)) / 365 AS OldestAge
FROM PROGRAMMER
WHERE Gender = 'Male';

--22. What is the average age of female programmers?
SELECT AVG(DATEDIFF(CURRENT_DATE, DateOfBirth)) / 365 AS avgAge
FROM PROGRAMMER
WHERE Gender = 'Female';

--23. Calculate the experience in years for each programmer and display with
--their names in descending order.

SELECT Name, DATEDIFF(CURRENT_DATE, StartDate) / 365 AS ExperienceInYears
FROM PROGRAMMER
ORDER BY ExperienceInYears DESC;

--24. Who are the programmers who celebrate their birthdays during the
--current month?
SELECT Name
FROM PROGRAMMER
WHERE MONTH(DateOfBirth) = MONTH(CURRENT_DATE)
      AND DAY(DateOfBirth) <= DAY(CURRENT_DATE);

--25. How many female programmers are there?

SELECT COUNT(*) AS NumberOfFemaleProgrammers
FROM PROGRAMMER
WHERE Gender = 'Female';


--26. What are the languages studied by male programmers?

SELECT COUNT(*) AS NumberOfmaleProgrammers
FROM PROGRAMMER
WHERE Gender = 'Male';

--27. What is the average salary?

SELECT AVG(SalaryAmount) AS averagesalary
FROM PROGRAMMER;


--28. How many people draw a salary between 2000 to 4000?

SELECT COUNT(*) AS NumberOfPeople
FROM SALARY
WHERE SalaryAmount >= 2000 AND SalaryAmount <= 4000;

--29. Display the details of those who don�t know Clipper, COBOL or Pascal.

SELECT COUNT(*) AS NumberOfProgrammers
FROM PROGRAMMER
WHERE Languages NOT IN ('Clipper', 'COBOL','Pascal');

--30. Display the cost of packages developed by each programmer.

SELECT programmer, SUM(DevelopmentCost) AS costofpackages
FROM SOFTWARE
GROUP BY programmer;


--31. Display the sales value of the packages developed by each
--programmer.

SELECT programmer, SUM(SellingCost) AS TotalSalesValue
FROM SOFTWARE
GROUP BY programmer;

--32. Display the number of packages sold by each programmer.

SELECT programmer, SUM(CopiesSold) AS numberofpackagessold
FROM SOFTWARE
GROUP BY programmer;

--33. Display the sales cost of the packages developed by each programmer
--language wise.
SELECT programmer, Language, SUM(SellingCost) AS TotalSalesCost
FROM SOFTWARE
GROUP BY programmer, Language;

--34. Display each language name with the average development cost,
--average selling cost and average price per copy.

SELECT Language,
       AVG(DevelopmentCost) AS AvgDevelopmentCost,
       AVG(SellingCost) AS AvgSellingCost,
       AVG(SellingCost / CopiesSold) AS AvgPricePerCopy--price per copy
FROM SOFTWARE
GROUP BY Language;

--35. Display each programmer�s name and the costliest and cheapest
--packages developed by him or her.

SELECT 
    P.Name AS ProgrammerName,
    S1.PackageName AS CostliestPackage,
    S2.PackageName AS CheapestPackage
FROM PROGRAMMER P
JOIN (
    SELECT Developer, MAX(SellingCost) AS MaxSellingCost,
	                  MIN(SellingCost) AS MinSellingCost
    FROM SOFTWARE
    GROUP BY Developer
) T ON P.Name = T.Developer
JOIN SOFTWARE S1 ON T.programmer = S1.programmer AND T.MaxSellingCost = S1.SellingCost
JOIN SOFTWARE S2 ON T.programmer = S2.programmer AND T.MinSellingCost = S2.SellingCost;



--36. Display each institute�s name with the number of courses and the
--average cost per course.
SELECT 
    InstituteName,
    COUNT(*) AS NumberOfCourses,
    AVG(CourseCost) AS AverageCostPerCourse
FROM STUDIES
GROUP BY InstituteName;

/*37. Display each institute�s name with the number of students.*/

SELECT Institute AS InstituteName, COUNT(*) AS NumberOfStudents
FROM STUDIES
GROUP BY Institute;

/*38. Display names of male and female programmers along with their
gender.*/
SELECT Name, Gender
FROM PROGRAMMER
WHERE Gender = 'Male' OR Gender = 'Female';

--39. Display the name of programmers and their packages.

SELECT P.Name AS ProgrammerName, S.PackageName AS DevelopedPackage
FROM PROGRAMMER P
JOIN SOFTWARE S ON P.Name = S.Developer;


--40. Display the number of packages in each language except C and C++.

SELECT Language,count(*) as numberofpackages
FROM SOFTWARE where (Language != 'C' or S.lanuage != 'C++');
--OR
SELECT Language, COUNT(*) AS NumberOfPackages
FROM SOFTWARE
WHERE Language NOT IN ('C', 'C++')
GROUP BY Language;


--41. Display the number of packages in each language for which
--development cost is less than 1000.

SELECT language, COUNT(*) AS NumberOfPackages
FROM SOFTWARE
WHERE development cost < 1000 GROUP BY Language;


--42. Display the average difference between SCOST and DCOST for each
--package.
SELECT PackageName, AVG(SCOST - DCOST) AS AvgCostDifference
FROM SOFTWARE
GROUP BY PackageName;


--43. Display the total SCOST, DCOST and the amount to be recovered for
--each programmer whose cost has not yet been recovered.

SELECT 
    programmer_id,
    SUM(SCOST) as total_SCOST,
    SUM(DCOST) as total_DCOST,
    (SUM(SCOST) + SUM(DCOST) - SUM(recovered_amount)) as amount_to_be_recovered
FROM programmers
GROUP BY programmer_id
HAVING amount_to_be_recovered > 0;

44. Display the highest, lowest and average salaries for those earning more
than 2000.
SELECT 
    MAX(SalaryAmount) AS HighestSalary,
    MIN(SalaryAmount) AS LowestSalary,
    AVG(SalaryAmount) AS AverageSalary
FROM SALARY
WHERE SalaryAmount > 2000;

45. Who is the highest paid C programmer?

SELECT P.Name AS ProgrammerName, S.SalaryAmount AS Salary
FROM PROGRAMMER P
JOIN SALARY S ON P.Name = S.Name
WHERE 'C' IN (SELECT * FROM STRING_SPLIT(Languages, ',')) 
ORDER BY S.SalaryAmount DESC
LIMIT 1;
/*Uses LIMIT 1 to get only the top result,Filters the results to only include C programmers.*/

46. Who is the highest paid female COBOL programmer?*/

SELECT P.Name AS ProgrammerName, S.SalaryAmount AS Salary
FROM PROGRAMMER P
JOIN SALARY S ON P.Name = S.Name
WHERE Gender = 'Female'
  AND 'COBOL' IN (SELECT * FROM STRING_SPLIT(Languages, ','))
ORDER BY S.SalaryAmount DESC
LIMIT 1;


/*47. Display the names of the highest paid programmers for each language.*/

SELECT Language, ProgrammerName, Salary
FROM (
    SELECT 
        S.Language,
        P.Name AS ProgrammerName,
        SalaryAmount AS Salary,
        ROW_NUMBER() OVER (PARTITION BY S.Language ORDER BY SalaryAmount DESC) AS Rank
    FROM SOFTWARE S
    JOIN PROGRAMMER P ON S.Developer = P.Name
    JOIN SALARY SA ON P.Name = SA.Name
) RankedProgrammers
WHERE Rank = 1;


--48. Who is the least experienced programmer?

SELECT Name AS ProgrammerName, 
       DATEDIFF(CURRENT_DATE, StartDate) AS ExperienceInDays
FROM PROGRAMMER
ORDER BY ExperienceInDays ASC
LIMIT 1;

--49. Who is the most experienced male programmer knowing PASCAL?

SELECT Name AS ProgrammerName, 
       DATEDIFF(CURRENT_DATE, StartDate) AS ExperienceInDays
FROM PROGRAMMER
WHERE Gender = 'Male'
  AND 'Pascal' IN (SELECT * FROM STRING_SPLIT(Languages, ','))
ORDER BY ExperienceInDays DESC
LIMIT 1;

--50. Which language is known by only one programmer?
--51. Who is the above programmer referred in 50?
--52. Who is the youngest programmer knowing dBase?

SELECT TOP 1 Name, Age
FROM Programmers
WHERE KnowledgeOfDBase = 'Yes'
ORDER BY Age ASC;

--53. Which female programmer earning more than 3000 does not know C,
--C++, Oracle or dBase?
/*assumed that you have a table named Programmers with
columns Name, Gender, Salary, KnowledgeOfC, KnowledgeOfCPP, KnowledgeOfOracle, and KnowledgeOfDBase, 
where the KnowledgeOfX 
columns indicate whether a programmer knows a specific language (with values like 'Yes' or 'No').*/
SELECT Name, Salary
FROM Programmers
WHERE Gender = 'Female'
  AND Salary > 3000
  AND NOT (KnowledgeOfC = 'Yes' OR KnowledgeOfCPP = 'Yes' OR KnowledgeOfOracle = 'Yes' OR KnowledgeOfDBase = 'Yes');

--54. Which institute has the most number of students?

SELECT InstituteName, COUNT(StudentID) AS TotalStudents
FROM Students
GROUP BY InstituteName
ORDER BY TotalStudents DESC
LIMIT 1;

55. What is the costliest course?

SELECT CourseName, Cost
FROM Studies
ORDER BY Cost DESC
LIMIT 1;

--56. Which course has been done by the most number of students?

SELECT CourseName, COUNT(*) AS StudentCount
FROM Enrollments
GROUP BY CourseName
ORDER BY StudentCount DESC
LIMIT 1;

--57. Which institute conducts the costliest course?

SELECT institutename, Cost
FROM Studies
GROUP BY institutename
ORDER BY Cost DESC
LIMIT 1;

--58. Display the name of the institute and the course which has below
--average course fee.
SELECT institutename, course,AVG(Cost) as average_course_fee
FROM Studies
GROUP BY institutename
ORDER BY average_course_fee ASC
LIMIT 1;

/*SELECT Institutes.InstituteName, Courses.CourseName
FROM Institutes
JOIN Courses ON Institutes.InstituteID = Courses.InstituteID
WHERE Courses.Cost < (SELECT AVG(Cost) FROM Courses);*/


--59. Display the names of the courses whose fees are within 1000 (+ or -) of
--the average fee.
SELECT CourseName
FROM Studies
WHERE Cost BETWEEN (SELECT AVG(Cost) - 1000 FROM Studies) AND (SELECT AVG(Cost) + 1000 FROM Studies);

--60. Which package has the highest development cost?

SELECT PackageName, DevelopmentCost
FROM Packages
ORDER BY DevelopmentCost DESC
LIMIT 1;


--61. Which course has below average number of students?

SELECT CourseName
FROM Studies
GROUP BY CourseName
HAVING COUNT(StudentID) < (SELECT AVG(NumStudents) FROM
(SELECT COUNT(StudentID) as NumStudents
FROM Enrollments GROUP BY CourseName) as StudentCounts);

--62. Which package has the lowest selling cost?

SELECT PackageName, SellingCost
FROM Packages
ORDER BY SellingCost ASC
LIMIT 1;

--63. Who developed the package that has sold the least number of copies?

SELECT DeveloperName
FROM Software
WHERE CopiesSold = (SELECT MIN(CopiesSold) FROM Software);

--64. Which language has been used to develop the package which has the
highest sales amount?

SELECT Language
FROM Software
WHERE SalesAmount = (SELECT MAX(SalesAmount) FROM Software);

--65. How many copies of the package that has the least difference between
--development and selling cost were sold?
SELECT CopiesSold
FROM Software
WHERE (SellingCost - DevelopmentCost) = (SELECT MIN(SellingCost - DevelopmentCost) FROM Software);

--66. Which is the costliest package developed in Pascal?

SELECT PackageName, Language, SellingCost
FROM Software
WHERE Language = 'Pascal'
ORDER BY SellingCost DESC
LIMIT 1;

--67. Which language was used to develop the most number of packages?
SELECT Language, COUNT(*) AS NumberOfPackages
FROM Software
GROUP BY Language
ORDER BY NumberOfPackages DESC
LIMIT 1;

--68. Which programmer has developed the highest number of packages?
 

SELECT ProgrammerName, COUNT(*) AS NumberOfPackages
FROM Software
GROUP BY ProgrammerName
ORDER BY NumberOfPackages DESC
LIMIT 1;

--69. Who is the author of the costliest package?

SELECT Author
FROM Software
WHERE SellingCost = (SELECT MAX(SellingCost) FROM Software);

--70. Display the names of the packages which have sold less than the
--average number of copies.

SELECT PackageName
FROM Software
WHERE CopiesSold < (SELECT AVG(CopiesSold) FROM Software);


--71. Who are the authors of the packages which have recovered more than
--double the development cost?
SELECT DISTINCT Author
FROM Packages
WHERE SellingCost > (2 * DevelopmentCost);

--72. Display the programmer names and the cheapest packages developed
--by them in each language.

SELECT s1.ProgrammerName, s1.DevelopmentLanguage, s1.PackageName, s1.SellingCost
FROM Software s1
WHERE s1.SellingCost = (
    SELECT MIN(s2.SellingCost)
    FROM Software s2
    WHERE s2.ProgrammerName = s1.ProgrammerName
      AND s2.DevelopmentLanguage = s1.DevelopmentLanguage
);

--73. Display the language used by each programmer to develop the highest
--selling and lowest selling package.
SELECT s.ProgrammerName, 
       s.DevelopmentLanguage, 
       s1.PackageName AS HighestSellingPackage, 
       s1.SellingCost AS HighestSellingCost, 
       s2.PackageName AS LowestSellingPackage, 
       s2.SellingCost AS LowestSellingCost
FROM Software s
JOIN (
    SELECT ProgrammerName, 
           DevelopmentLanguage, 
           PackageName, 
           SellingCost
    FROM Software
    WHERE SellingCost = (
        SELECT MAX(SellingCost)
        FROM Software
        WHERE ProgrammerName = s.ProgrammerName AND DevelopmentLanguage = s.DevelopmentLanguage
    )
) s1 ON s.ProgrammerName = s1.ProgrammerName AND s.DevelopmentLanguage = s1.DevelopmentLanguage
JOIN (
    SELECT ProgrammerName, 
           DevelopmentLanguage, 
           PackageName, 
           SellingCost
    FROM Software
    WHERE SellingCost = (
        SELECT MIN(SellingCost)
        FROM Software
        WHERE ProgrammerName = s.ProgrammerName AND DevelopmentLanguage = s.DevelopmentLanguage
    )
) s2 ON s.ProgrammerName = s2.ProgrammerName AND s.DevelopmentLanguage = s2.DevelopmentLanguage

--74. Who is the youngest male programmer born in 1965?

SELECT ProgrammerName, BirthYear
FROM PROGRAMMER
WHERE Gender = 'Male'
  AND BirthYear = 1965
ORDER BY BirthYear DESC
LIMIT 1;

--75. Who is the oldest female programmer who joined in 1992?

SELECT ProgrammerName, BirthYear
FROM PROGRAMMER
WHERE Gender = 'Female'
  AND YEAR(JoinDate) = 1992
ORDER BY BirthYear ASC
LIMIT 1;

--76. In which year was the most number of programmers born?
SELECT BirthYear, COUNT(*) AS NumberOfProgrammers
FROM PROGRAMMER
GROUP BY BirthYear
ORDER BY NumberOfProgrammers DESC
LIMIT 1;

--77. In which month did the most number of programmers join?

SELECT MONTH(JoinDate) AS JoinMonth, COUNT(*) AS NumberOfProgrammers
FROM PROGRAMMER
GROUP BY JoinMonth
ORDER BY NumberOfProgrammers DESC
LIMIT 1;


--78. In which language are most of the programmer�s proficient?

SELECT ProficientLanguage, COUNT(*) AS NumberOfProgrammers
FROM PROGRAMMER
GROUP BY ProficientLanguage
ORDER BY NumberOfProgrammers DESC
LIMIT 1;

--79. Who are the male programmers earning below the average salary of
female programmers?

SELECT Male.ProgrammerName, Male.Salary, AVG(Female.Salary) AS AverageFemaleSalary
FROM PROGRAMMER Male
JOIN PROGRAMMER Female ON Male.Gender = 'Male' AND Female.Gender = 'Female'
WHERE Male.Salary < AVG(Female.Salary)
GROUP BY Male.ProgrammerName, Male.Salary;

--80. Who are the female programmers earning more than the highest paid?

SELECT ProgrammerName, Gender, Salary
FROM PROGRAMMER
WHERE Gender = 'Female'
  AND Salary > (SELECT MAX(Salary) FROM PROGRAMMER);

--81. Which language has been stated as the proficiency by most of the
--programmers?
SELECT ProficientLanguage, COUNT(*) AS NumberOfProgrammers
FROM PROGRAMMER
GROUP BY ProficientLanguage
ORDER BY NumberOfProgrammers DESC
LIMIT 1;

--82. Display the details of those who are drawing the same salary.

SELECT ProgrammerName, Gender, Salary
FROM PROGRAMMER
GROUP BY ProgrammerName, Gender, Salary
HAVING COUNT(*) > 1;
/*HAVING COUNT(*) > 1: This condition ensures that only individuals with the 
same combination of name, gender, and salary are included.*/

--83. Display the details of the software developed by the male programmers
--earning more than 3000.

SELECT s.ProgrammerName, s.PackageName, s.DevelopmentLanguage, s.SellingCost
FROM SOFTWARE s
JOIN PROGRAMMER p ON s.ProgrammerName = p.ProgrammerName
WHERE p.Gender = 'Male' AND p.Salary > 3000;

--84. Display the details of the packages developed in Pascal by the female
--programmers.

SELECT s.PackageName, s.DevelopmentLanguage, s.SellingCost
FROM SOFTWARE s
JOIN PROGRAMMER p ON s.ProgrammerName = p.ProgrammerName
WHERE p.Gender = 'Female' AND s.DevelopmentLanguage = 'Pascal';

--85. Display the details of the programmers who joined before 1990.

SELECT *
FROM PROGRAMMER
WHERE YEAR(JoinDate) < 1990;

--86. Display the details of the software developed in C by the female
--programmers at Pragathi.

SELECT s.PackageName, s.DevelopmentLanguage, s.SellingCost
FROM SOFTWARE s
JOIN PROGRAMMER p ON s.ProgrammerName = p.ProgrammerName
WHERE p.Gender = 'Female' AND p.Institute = 'Pragathi' AND s.DevelopmentLanguage = 'C';

--87. Display the number of packages, number of copies sold and sales value
--of each programmer institute wise.

SELECT p.Institute, 
       COUNT(s.PackageName) AS NumberOfPackages, 
       SUM(s.CopiesSold) AS TotalCopiesSold, 
       SUM(s.SellingCost * s.CopiesSold) AS TotalSalesValue
FROM PROGRAMMER p
LEFT JOIN SOFTWARE s ON p.ProgrammerName = s.ProgrammerName
GROUP BY p.Institute

--88. Display the details of the software developed in dBase by male
--programmers who belong to the institute in which the most number of
--programmers studied.
SELECT s.PackageName, s.DevelopmentLanguage, s.SellingCost
FROM SOFTWARE s
JOIN PROGRAMMER p ON s.ProgrammerName = p.ProgrammerName
WHERE p.Gender = 'Male'
  AND p.Institute = (
    SELECT Institute
    FROM PROGRAMMER
    GROUP BY Institute
    ORDER BY COUNT(*) DESC
    LIMIT 1
  )
  AND s.DevelopmentLanguage = 'dBase';

--89. Display the details of the software developed by the male programmers
--born before 1965 and female programmers born after 1975.

SELECT s.PackageName, s.DevelopmentLanguage, s.SellingCost
FROM SOFTWARE s
JOIN PROGRAMMER p ON s.ProgrammerName = p.ProgrammerName
WHERE (p.Gender = 'Male' AND p.BirthYear < 1965)
   OR (p.Gender = 'Female' AND p.BirthYear > 1975);

/*90. Display the details of the software that has been developed in the
language which is neither the first nor the second proficiency of the
programmers.*/
SELECT s.PackageName, s.DevelopmentLanguage, s.SellingCost
FROM SOFTWARE s
JOIN PROGRAMMER p ON s.ProgrammerName = p.ProgrammerName
WHERE s.DevelopmentLanguage NOT IN (p.ProficientLanguage, p.SecondProficiency);

--91. Display the details of the software developed by the male students at
--Sabhari.

SELECT s.PackageName, s.DevelopmentLanguage
FROM SOFTWARE s
JOIN PROGRAMMER p ON s.ProgrammerName = p.ProgrammerName
WHERE p.Gender = 'Male' AND p.Institute = 'Sabhari';

--92. Display the names of the programmers who have not developed any
--packages.
SELECT ProgrammerName
FROM PROGRAMMER
WHERE ProgrammerName NOT IN (
    SELECT DISTINCT ProgrammerName
    FROM SOFTWARE
);

--93. What is the total cost of the software developed by the programmers of
--Apple?
SELECT SUM(DevelopmentCost) AS TotalCost
FROM SOFTWARE
WHERE ProgrammerName IN (
    SELECT ProgrammerName
    FROM PROGRAMMER
    WHERE Institute = 'Apple'
);

--94. Who are the programmers who joined on the same day?

SELECT JoinDate, GROUP_CONCAT(ProgrammerName) AS JoinedProgrammers
FROM PROGRAMMER
GROUP BY JoinDate
HAVING COUNT(*) > 1;

--95. Who are the programmers who have the same Prof2?

SELECT Prof2, GROUP_CONCAT(ProgrammerName) AS ProgrammersWithSameProf2
FROM PROGRAMMER
GROUP BY Prof2
HAVING COUNT(*) > 1;

--96. Display the total sales value of the software institute wise.

SELECT p.Institute, SUM(s.SellingCost * s.CopiesSold) AS TotalSalesValue
FROM PROGRAMMER p
JOIN SOFTWARE s ON p.ProgrammerName = s.ProgrammerName
GROUP BY p.Institute;

--97. In which institute does the person who developed the costliest package
--study?

SELECT p.Institute
FROM PROGRAMMER p
JOIN SOFTWARE s ON p.ProgrammerName = s.ProgrammerName
WHERE s.DevelopmentCost = (SELECT MAX(DevelopmentCost) FROM SOFTWARE);

--98. Which language listed in Prof1, Prof2 has not been used to develop any
--package?
SELECT Language
FROM (
    SELECT Prof1 AS Language FROM PROGRAMMER
    UNION
    SELECT Prof2 AS Language FROM PROGRAMMER
) AS Proficiencies
WHERE Language NOT IN (
    SELECT DISTINCT DevelopmentLanguage FROM SOFTWARE
);


--99. How much does the person who developed the highest selling package
--earn and what course did he/she undergo?

SELECT p.ProgrammerName, p.Salary, p.Course
FROM PROGRAMMER p
JOIN SOFTWARE s ON p.ProgrammerName = s.ProgrammerName
WHERE s.SellingCost = (SELECT MAX(SellingCost) FROM SOFTWARE);

--100. What is the average salary for those whose software sales is more than
--50,000?
SELECT AVG(Salary) AS AverageSalary
FROM PROGRAMMER
WHERE ProgrammerName IN (
    SELECT DISTINCT ProgrammerName
    FROM SOFTWARE
    WHERE SellingCost * CopiesSold > 50000
);

--101. How many packages were developed by students who studied in
--institutes that charge the lowest course fee?
SELECT COUNT(s.PackageName) AS NumberOfPackages
FROM SOFTWARE s
JOIN PROGRAMMER p ON s.ProgrammerName = p.ProgrammerName
WHERE p.Institute IN (
    SELECT Institute
    FROM PROGRAMMER
    WHERE CourseFee = (
        SELECT MIN(CourseFee)
        FROM PROGRAMMER
    )
);

--102. How many packages were developed by the person who developed the
--cheapest package? Where did he/she study?
SELECT p.ProgrammerName, p.Institute, COUNT(s.PackageName) AS NumberOfPackages
FROM PROGRAMMER p
JOIN SOFTWARE s ON p.ProgrammerName = s.ProgrammerName
WHERE s.DevelopmentCost = (
    SELECT MIN(DevelopmentCost)
    FROM SOFTWARE
)
GROUP BY p.ProgrammerName, p.Institute;

--103. How many packages were developed by female programmers earning
--more than the highest paid male programmer?

SELECT COUNT(s.PackageName) AS NumberOfPackages
FROM SOFTWARE s
JOIN PROGRAMMER p ON s.ProgrammerName = p.ProgrammerName
WHERE p.Gender = 'Female'
  AND p.Salary > (
    SELECT MAX(Salary)
    FROM PROGRAMMER
    WHERE Gender = 'Male'
);

--104. How many packages are developed by the most experienced
--programmers from BDPS?
SELECT COUNT(s.PackageName) AS NumberOfPackages
FROM SOFTWARE s
JOIN PROGRAMMER p ON s.ProgrammerName = p.ProgrammerName
WHERE p.Institute = 'BDPS'
  AND p.YearsOfExperience = (
    SELECT MAX(YearsOfExperience)
    FROM PROGRAMMER
    WHERE Institute = 'BDPS'
);

--105. List the programmers (from the software table) and the institutes they
--studied at.

SELECT s.ProgrammerName, p.Institute
FROM SOFTWARE s
JOIN PROGRAMMER p ON s.ProgrammerName = p.ProgrammerName;

--106. List each PROF with the number of programmers having that PROF
--and the number of the packages in that PROF.

SELECT 
    Proficiency,
    COUNT(DISTINCT p.ProgrammerName) AS NumberOfProgrammers,
    COUNT(s.PackageName) AS NumberOfPackages
FROM 
    PROGRAMMER p
JOIN 
    SOFTWARE s ON p.ProgrammerName = s.ProgrammerName
GROUP BY 
    Proficiency;

--107. List the programmer names (from the programmer table) and the
--number of packages each has developed.

SELECT p.ProgrammerName, COUNT(s.PackageName) AS NumberOfPackages
FROM PROGRAMMER p
LEFT JOIN SOFTWARE s ON p.ProgrammerName = s.ProgrammerName
GROUP BY p.ProgrammerName;
