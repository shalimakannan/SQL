--CREATE DATABASE casestudy3;
USE casestudy3;



SELECT * FROM Continent1;

SELECT * FROM Customers1;

SELECT * FROM transaction1;

--1. Display the count of customers in each region who have done the
--transaction in the year 2020.
SELECT c.region_id, COUNT(DISTINCT c.customer_id) AS customer_count
FROM Customers1 c
JOIN transaction1 t ON c.customer_id = t.customer_id
WHERE YEAR(t.txn_date) = 2020
GROUP BY c.region_id

--2. Display the maximum and minimum transaction amount of each
--transaction type.
SELECT 
    txn_type,
    MAX(txn_amount) AS max_amount,
    MIN(txn_amount) AS min_amount
FROM transaction1
GROUP BY txn_type;

--3. Display the customer id, region name and transaction amount where
--transaction type is deposit and transaction amount > 2000.
SELECT 
    c.customer_id,
	co.region_name,
    t.txn_amount
FROM Customers1 c
JOIN Continent1 co ON co.region_id=c.region_id
JOIN transaction1 co ON co.customer_id=c.customer_id
WHERE txn_type='deposit' AND txn_amount>2000


--4. Find duplicate records in the Customer table.
SELECT customer_id
FROM Customers1
GROUP BY customer_id
HAVING COUNT(customer_id)>1
		

--5. Display the customer id, region name, transaction type and transaction
--amount for the minimum transaction amount in deposit.
SELECT 
    c.customer_id,
	co.region_name,
    t.txn_type,
	t.txn_amount,
FROM Customers1 c
JOIN Continent1 co ON co.region_id=c.region_id
JOIN transaction1 co ON co.customer_id=c.customer_id
WHERE 
    t.txn_type = 'deposit'
    AND t.txn_amount = (
        SELECT MIN(txn_amount) 
        FROM transaction1 
        WHERE txn_type = 'deposit')


--6. Create a stored procedure to display details of customers in the
--Transaction table where the transaction date is greater than Jun 2020.

CREATE PROCEDURE CustomersdetailsAfterJun2020
AS
BEGIN
    SELECT c.customer_id, c.region_id, t.txn_date, t.txn_type, t.txn_amount
    FROM Customers1 c
    JOIN transaction1 t ON c.customer_id = t.customer_id
    WHERE t.txn_date > '2020-06-30';
END

--7. Create a stored procedure to insert a record in the Continent table.
CREATE PROCEDURE InsertRecordInContinent
    @region_id INT,
    @region_name VARCHAR(255)
AS
BEGIN
    INSERT INTO Continent1 (region_id, region_name)
    VALUES (@region_id, @region_name)
END

--8. Create a stored procedure to display the details of transactions that
--happened on a specific day.
CREATE PROCEDURE GetTransactionsOnDate
    @specific_date DATE
AS
BEGIN
    SELECT *
    FROM transaction1
    WHERE CONVERT(DATE, txn_date) = @specific_date;
END

--9. Create a user defined function to add 10% of the transaction amount in a
--table.
CREATE FUNCTION dbo.AddTenPercent
(
    @Amount DECIMAL(18,2)
)
RETURNS DECIMAL(18,2)
AS
BEGIN
    DECLARE @NewAmount DECIMAL(18,2);

    SET @NewAmount = @Amount + (@Amount * 0.10);

    RETURN @NewAmount;
END;
SELECT dbo.AddTenPercent(txn_amount) AS NewAmount
FROM transaction1;

--10. Create a user defined function to find the total transaction amount for a
--given transaction type.
CREATE FUNCTION dbo.GetTotalTransactionAmountByType
(
    @TransactionType VARCHAR(50)
)
RETURNS DECIMAL(18,2)
AS
BEGIN
    DECLARE @TotalAmount DECIMAL(18,2);

    SELECT @TotalAmount = SUM(txn_amount)
    FROM transaction1
    WHERE txn_type = @TransactionType;

    RETURN @TotalAmount;
END;

--11. Create a table value function which comprises the columns customer_id,
--region_id ,txn_date , txn_type , txn_amount which will retrieve data from
--the above table.
CREATE FUNCTION dbo.GetData()
RETURNS TABLE
AS
RETURN (
    SELECT customer_id, region_id, txn_date, txn_type, txn_amount
    FROM 
    Customers1 c
JOIN 
    Continent1 co ON c.region_id = co.region_id
JOIN 
    transaction1 t ON t.customer_id = c.customer_id; 

);
SELECT * FROM dbo.GetData();

--12. Create a TRY...CATCH block to print a region id and region name in a
--single column.
select * from Continent1;
BEGIN TRY
    SELECT 
        CAST(region_id AS VARCHAR(10)) + ' - ' + region_name AS singlecolumn
    FROM Continent1;
END TRY
BEGIN CATCH
    SELECT 
        NULL AS singlecolumn,
        'An error occurred: ' + ERROR_MESSAGE() AS ErrorMessage;
END CATCH

--13. Create a TRY...CATCH block to insert a value in the Continent table.
BEGIN TRY
    
    INSERT INTO Continent1 (region_name)
    VALUES ('Asia'); 
END TRY
BEGIN CATCH
    
    PRINT 'An error occurred: ' + ERROR_MESSAGE();
END CATCH

--14. Create a trigger to prevent deleting a table in a database.
REVOKE DROP ON Continent1 TO shal;

--15. Create a trigger to audit the data in a table.

--JUST A SYNTAX
CREATE TRIGGER AuditTrigger
ON TargetTable
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    -- Insert audit records for INSERT operations
    INSERT INTO AuditTable (Action, ChangedBy, ChangeDate, OldValue, NewValue)
    SELECT 'INSERT', SUSER_NAME(), GETDATE(), NULL, NewColumn
    FROM inserted;

    -- Insert audit records for UPDATE operations
    INSERT INTO AuditTable (Action, ChangedBy, ChangeDate, OldValue, NewValue)
    SELECT 'UPDATE', SUSER_NAME(), GETDATE(), OldColumn, NewColumn
    FROM deleted
    JOIN inserted ON deleted.PrimaryKey = inserted.PrimaryKey;

    -- Insert audit records for DELETE operations
    INSERT INTO AuditTable (Action, ChangedBy, ChangeDate, OldValue, NewValue)
    SELECT 'DELETE', SUSER_NAME(), GETDATE(), OldColumn, NULL
    FROM deleted;
END;

--16. Create a trigger to prevent login of the same user id in multiple pages.
 --ANS:In SQL Server, you can't directly prevent the same user from logging in on multiple pages 
--using a trigger.
--Triggers are designed to work on database events like INSERT, UPDATE, or DELETE operations, not on user login events.
--17. Display top n customers on the basis of transaction type.
WITH RankedTransactions AS (
    SELECT 
        customer_id,
        txn_type,
        txn_amount,
        ROW_NUMBER() OVER (PARTITION BY txn_type ORDER BY txn_amount DESC) AS Rank
    FROM transaction1
)
SELECT
    customer_id,
    txn_type,
    txn_amount
FROM RankedTransactions
WHERE Rank <= N;

--18. Create a pivot table to display the total purchase, withdrawal and
--deposit for all the customers.SELECT *
FROM (
    SELECT customer_id, txn_type, txn_amount
    FROM transaction1
) AS SourceTable
PIVOT (
    SUM(txn_amount)
    FOR txn_type IN ([Purchase], [Withdrawal], [Deposit])
) AS PivotTable;
--Syntax
/*
CREATE FUNCTION [database_name.]function_name (parameters)
RETURNS data_type AS
BEGIN
    SQL statements
    RETURN value
END;
    
ALTER FUNCTION [database_name.]function_name (parameters)
RETURNS data_type AS
BEGIN
    SQL statements
    RETURN value
END;
    
DROP FUNCTION [database_name.]function_name;*/