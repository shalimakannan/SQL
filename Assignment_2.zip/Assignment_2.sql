
/*Create a customer table which comprises of these columns: �customer_id�,
�first_name�, �last_name�, �email�, �address�, �city�,�state�,�zip�*/
DROP DATABASE customer_data;

CREATE database customer_data;
use customer_data;
/*1. Create a customer table which comprises of these columns: �customer_id�,
�first_name�, �last_name�, �email�, �address�,�city�,�state�,�zip�*/
drop table cust_details;
 CREATE TABLE cust_details (
               customer_id INT PRIMARY KEY,
               first_name VARCHAR(50),
               last_name VARCHAR(50),
               email VARCHAR(50),
               address VARCHAR(50),
               city VARCHAR(50),
               state VARCHAR(50),
	           zip VARCHAR(10));

/*2. Insert 5 new records into the table*/

INSERT INTO cust_details (customer_id, first_name, last_name, email, address, city, state, zip)
VALUES
    (1, 'dhyan', 'Kannan', 'dhyan.kannan@gmail.com', '123 Main St', 'Anytown', 'CA', '12345'),
    (2, 'John', 'Fransis', 'john.fransis@gmail.com', '456 Oak Ave', 'Sometown', 'NY', '54321'),
    (3, 'Kiran', 'Surya', 'kiransurya@outlook.com', '789 Elm Blvd', 'Othertown', 'TX', '67890'),
    (4, 'Gowri', 'Chandh', 'sonamchandh@gmail.com', '101 Pine Dr', 'SanJose', 'FL', '45678'),
    (5, 'shan', 'sony', 'shansony@outlook.com', '202 Cedar Ln', 'Newtown', 'OH', '23456');
	select * from cust_details;

/*Select only the �first_name� and �last_name� columns from the customer
table*/
select first_name,last_name from cust_details;

/*1. Create an �Orders� table which comprises of these columns: �order_id�,
�order_date�, �amount�, �customer_id�*/
drop table Orders;

/*4. Select those records where �first_name� starts with �G� and city is �San
Jose�.*/
select first_name,city from cust_details where (first_name like'G%' and city='SanJose');

/* 5. Select those records where Email has only �gmail�.*/
/*select email from cust_details where (email like '%gmail');*/
SELECT * FROM cust_details WHERE email LIKE '%gmail.com';

/*6. Select those records where the �last_name� doesn't end with �A�.*/

SELECT * FROM cust_details WHERE last_name NOT LIKE '%A';

/*1. Create an �Orders� table which comprises of these columns: �order_id�,
�order_date�, �amount�, �customer_id�.*/
CREATE TABLE Orders (
    order_id INT PRIMARY KEY,
    order_date DATE,
    amount DECIMAL(10, 2), -- Assuming 2 decimal places for the amount
    customer_id INT,
    /*FOREIGN KEY (customer_id) REFERENCES Customers(customer_id)*/
);

/*2. Insert 5 new records.*/

INSERT INTO Orders (order_id, order_date, amount, customer_id)
VALUES
    (1, '2021-09-10', 100.00, 1),
    (2, '2021-09-11', 150.50, 2),
    (3, '2021-09-12', 200.75, 3),
    (4, '2021-09-13', 75.25, 6),
    (5, '2021-09-14', 300.00, 7);

select * from Orders;

/* 3. Make an inner join on �Customer� and �Orders� tables on the �customer_id� column.*/


SELECT C.customer_id, C.first_name, C.last_name, O.order_id, O.order_date
FROM cust_details C
INNER JOIN Orders O ON C.customer_id = O.customer_id;


/* 4. Make left and right joins on �Customer� and �Orders� tables on the
�customer_id� column.*/

SELECT C.customer_id, C.first_name, C.last_name, O.order_id, O.order_date
FROM cust_details C
LEFT  JOIN Orders O ON C.customer_id = O.customer_id;


/*5. Make a full outer join on �Customer� and �Orders� table on the �customer_id� column.*/


SELECT C.customer_id, C.first_name, C.last_name, O.order_id, O.order_date
FROM cust_details C
FULL  JOIN Orders O ON C.customer_id = O.customer_id;

/* 6. Update the �Orders� table and set the amount to be 100 where
�customer_id� is 3.*/
update orders
set amount = 100
where customer_id = 3;


 