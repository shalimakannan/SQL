use customer_data;
/*Tasks To Be Performed:
1. Use the inbuilt functions and find the minimum, maximum and average
amount from the orders table*/
 select * from orders;
 select MIN(amount) as min_amount from orders;
 select Max(amount) as max_amount from orders;
 select avg(amount) as avg_amount from orders;


/*2. Create a user-defined function which will multiply the given number with 10*/


CREATE FUNCTION MultiplyBy10 (@input_number INT)
RETURNS INT
AS
BEGIN
    RETURN @input_number * 10;
END;
SELECT dbo.MultiplyBy10(3);

/*3. Use the case statement to check if 100 is less than 200,
                           greater than 200 or equal to 200 
						   and print the corresponding value. */

SELECT 
    CASE 
        WHEN 100 < 200 THEN 'Less than 200'
        WHEN 100 > 200 THEN 'Greater than 200'
        ELSE 'Equal to 200'
    END AS result;
/*The result of this query will be a single column named result,
which will contain the message 'Less than 200' since 100 is indeed less than 200. 
If you change the comparison values,
you'll get different results based on the conditions specified in the CASE statement.*/

/*
4. Using a case statement, find the status of the amount. Set the status of the
amount as high amount, low amount or medium amount based upon the
condition.*/

select * from order_s;

SELECT 
    amount,
    CASE 
        WHEN amount > 1000 THEN 'High amount'
        WHEN amount < 500 THEN 'Low amount'
        ELSE 'Medium amount'
    END AS amount_status 
from order_s;


/* 5. Create a user-defined function, to fetch the amount greater than then given
input*/
CREATE FUNCTION AmountsGreaterThanInput (@input_amount DECIMAL(10, 2))
RETURNS TABLE
AS
RETURN
(
    SELECT amount
    FROM order_s
    WHERE amount > @input_amount
);

SELECT * FROM dbo.AmountsGreaterThanInput(150.00);
