use customer_data;
select * from cust_details;

/*Tasks To Be Performed:
1. Create an �Orders� table which comprises of these columns: �order_id�,
�order_date�, �amount�, �customer_id�*/

create table order_s(
                     order_id int primary key,
					 order_date date,
					 amount decimal(10,2),
					 customer_id int);

/*2. Insert 5 new records*/

INSERT INTO order_s (order_id, order_date, amount, customer_id)
VALUES  (1, '2023-09-10', 100.00, 1),
        (2, '2023-09-11', 150.50, 2),
	    (3, '2023-09-12', 200.75, 3),
		(4, '2023-09-13', 75.25, 4),
		(5, '2023-09-14', 300.00, 5);

select * from order_s;

/*3. Make an inner join on �Customer� and �Orders� tables on the �customer_id� column.*/

select * from cust_details c inner join order_s o ON c.customer_id=o.customer_id;


/*4. Make left and right joins on �Customer� and �Orders� tables on the
�customer_id� column.*/


select * from cust_details c left join order_s o ON c.customer_id=o.customer_id;


select * from cust_details c right join order_s o ON c.customer_id=o.customer_id;

/* 5. Make a full outer join on �Customer� and �Orders� table on the �customer_id� column.*/

select * from cust_details c full outer join order_s o ON c.customer_id=o.customer_id;

/*6. Update the �Orders� table and set the amount to be 100 where
�customer_id� is 3*/
 update  order_s set amount = 100 where  customer_id =3;   
 
 select * from order_s;